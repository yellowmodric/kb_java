package ch12.sec03.exam04;

public record Memeber(String id, String name, int age) {

}
